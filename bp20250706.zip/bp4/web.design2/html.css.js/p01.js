function btnred_onclick() {
    alert('pressed: red button');
}

function btngreen_onclick() {
    alert('pressed: green button');
}

function btnblue_onclick() {
    alert('pressed: blue button');
}
